# Change Log
## [3.3.1] - 2024-06-11
fixes issues in the latest font update

## [3.3.0] - 2024-06-11
update fonts to current version in flaticon

## [3.2.1] - 2024-04-12
fix build thin style

## [3.2.0] - 2024-04-10
update fonts to current version in flaticon

## [3.1.0] - 2024-01-02
update fonts to current version in flaticon

## [3.0.0] - 2023-19-10
update fonts to current version in flaticon

## [2.4.0] - 2023-08-10
update readme
## [2.3.0] - 2023-05-12
update fonts to current version in flaticon and change license

## [2.2.0] - 2023-05-12
update fonts to current version in flaticon

## [2.1.0] - 2023-04-21
update fonts to current version in flaticon

## [2.0.1] - 2023-02-06
we do not show license after installation

## [2.0.0] - 2023-01-13
update fonts to current version in flaticon 

## [1.7.1] - 2023-01-13

We corrected some problems that prevented the correct use of the library

## [1.7.0] - 2017-03-15

Here we would have the update steps for 1.2.4 for people to follow.

### Added

We add interface icons for brands to our library

### Changed

Update of all our interface icons

- feat : Add uicons brands
- FI-11899_add_uicons_brands

## [1.0.0] - 2022-01-14

### Added

First version with all interface icons available in flaticon

- FI-uicons Config and Start
- Initial commit
